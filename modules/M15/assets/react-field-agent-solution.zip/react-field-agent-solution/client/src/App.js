import Agents from './components/Agents';

function App() {
  return (
    <>
      <h1 className="py-2">Field Agents</h1>
      <Agents />
    </>
  );
}

export default App;
