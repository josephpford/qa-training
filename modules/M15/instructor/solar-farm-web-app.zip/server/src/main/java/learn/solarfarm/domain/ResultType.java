package learn.solarfarm.domain;

public enum ResultType {
    SUCCESS,
    INVALID,
    NOT_FOUND
}
