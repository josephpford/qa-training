
let solarPanels = [];
let editSolarPanelId = 0;

function setCurrentView(view) {
  const formContainerElement = document.getElementById('formContainer');
  const listContainerElement = document.getElementById('listContainer');

  switch (view) {
    case 'List':
      formContainerElement.style.display = 'none';
      listContainerElement.style.display = 'block';
      break;
    case 'Form':
      formContainerElement.style.display = 'block';
      listContainerElement.style.display = 'none';
      break;
  }
}

function displayList() {
  setCurrentView('List');
  getSolarPanels()
    .then(data => {
      solarPanels = data;
      renderList(data);
    });
}

function getSolarPanels() {
  return fetch('http://localhost:8080/api/solarpanel') // returns a promise
    .then(response => {
        return response.json();
    });
}

function handleSubmit(event) {
  event.preventDefault(); // this stops the browser from submitting the form

  // const formElement = event.target;
  // const formData = new FormData(formElement);

  // const solarPanel = {
  //   section: formData.get('section'),
  //   row: formData.get('row') ? parseInt(formData.get('row')) : 0,
  //   column: formData.get('column') ? parseInt(formData.get('column')) : 0,
  //   yearInstalled: formData.get('yearInstalled') ? parseInt(formData.get('yearInstalled')) : 0,
  //   material: formData.get('material'),
  //   tracking: formData.get('tracking') ? true : false
  // };

  const section = document.getElementById('section').value;
  const row = document.getElementById('row').value;
  const column = document.getElementById('column').value;
  const yearInstalled = document.getElementById('yearInstalled').value;
  const material = document.getElementById('material').value;
  const tracking = document.getElementById('tracking').checked;

  const solarPanel = {
    section,
    row: row ? parseInt(row) : 0,
    column: column ? parseInt(column) : 0,
    yearInstalled: yearInstalled ? parseInt(yearInstalled) : 0,
    material,
    tracking
  };

  if (editSolarPanelId > 0) {
    doPut(solarPanel);
  } else {
    doPost(solarPanel);
  }
}

function doPost(solarPanel) {
  const init = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(solarPanel)
  };

  fetch('http://localhost:8080/api/solarpanel', init)
    .then(response => {
      if (response.status === 201 || response.status === 400) {
        return response.json();
      } else {
        return Promise.reject(`Unexpected status code: ${response.status}`);
      }
    })
    .then(data => {
      if (data.id) {
        displayList();
        resetState();
      } else {
        renderErrors(data);
      }
    })
    .catch(console.log);
}

function doPut(solarPanel) {
  solarPanel.id = editSolarPanelId;

  const init = {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(solarPanel)
  };

  fetch(`http://localhost:8080/api/solarpanel/${editSolarPanelId}`, init)
    .then(response => {
      if (response.status === 204) {
        return null;
      } else if (response.status === 400) {
        return response.json();
      } else {
        return Promise.reject(`Unexpected status code: ${response.status}`);
      }
    })
    .then(data => {
      if (!data) {
        displayList();
        resetState();
      } else {
        renderErrors(data);
      }
    })
    .catch(console.log);
}

function handleAddPanel() {
  setCurrentView('Form');
}

function handleEditPanel(solarPanelId) {
  const solarPanel = solarPanels.find(solarPanel => solarPanel.id === solarPanelId);

  document.getElementById('section').value = solarPanel.section;
  document.getElementById('row').value = solarPanel.row;
  document.getElementById('column').value = solarPanel.column;
  document.getElementById('yearInstalled').value = solarPanel.yearInstalled;
  document.getElementById('material').value = solarPanel.material;
  document.getElementById('tracking').checked = solarPanel.tracking;

  document.getElementById('formHeading').innerText = 'Update Solar Panel';
  document.getElementById('formSubmitButton').innerText = 'Update Solar Panel';

  editSolarPanelId = solarPanelId;

  setCurrentView('Form');
}

function handleDeletePanel(solarPanelId) {
  const solarPanel = solarPanels.find(solarPanel => solarPanel.id === solarPanelId);

  if (confirm(`Delete the panel at the location ${solarPanel.section}-${solarPanel.row}-${solarPanel.column}?`)) {
    const init = {
      method: 'DELETE'
    };

    fetch(`http://localhost:8080/api/solarpanel/${solarPanelId}`, init)
      .then(response => {
        if (response.status === 204) {
          displayList();
          resetState();
        } else {
          return Promise.reject(`Unexpected status code: ${response.status}`);
        }
      })
      .catch(console.log);
  }
}

function renderErrors(errors) {
  const errorsHtml = errors.map(error => `<li>${error}</li>`);
  const errorsHtmlString = `
    <div class="alert alert-danger">
      <p>The following errors were found:</p>
      <ul>
        ${errorsHtml.join('')}
      </ul>
    </div>
  `;
  document.getElementById('errors').innerHTML = errorsHtmlString;
}

function resetState() {
  document.getElementById('form').reset();
  document.getElementById('formHeading').innerText = 'Add Solar Panel';
  document.getElementById('formSubmitButton').innerText = 'Add Solar Panel';
  document.getElementById('errors').innerHTML = '';
  editSolarPanelId = 0;
  setCurrentView('List');
}

function renderList(solarPanels) {
  const solarPanelsHtml = solarPanels.map(solarPanel => {
    return `
      <tr>
        <td>${solarPanel.section}</td>
        <td>${solarPanel.row}-${solarPanel.column}</td>
        <td>${solarPanel.yearInstalled}</td>
        <td>${solarPanel.material}</td>
        <td>${solarPanel.tracking ? 'Yes' : 'No'}</td>
        <td>
          <div class="float-right mr-2">
            <button class="btn btn-primary btn-sm" onclick="handleEditPanel(${solarPanel.id})">
              <i class="bi bi-pencil-square"></i> Edit
            </button>
            <button class="btn btn-danger btn-sm" onclick="handleDeletePanel(${solarPanel.id})">
              <i class="bi bi-trash"></i> Delete
            </button>
          </div>
        </td>
      </tr>
    `;
  });
  
  // to fix injection risks...
  // 1) we could use a templating library... handlebars
  // 2) we could use React
  const tableBodyElement = document.getElementById('tableRows');
  tableBodyElement.innerHTML = solarPanelsHtml.join('');
}

displayList();
